import pygame
import sys

pygame.init()
width = 1920
height = 1080

screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Forward")

# Library of all the custom colors I'm using
colors = {
    "Black": (0, 0, 0), "White": (255, 255, 255), "Red": (255, 0, 0), "Green": (0, 255, 0), "Blue": (0, 0, 255),
    "character": (25, 60, 30), "character outline": (255, 230, 0),
    "doable level": (80, 150, 200), "complete level": (30, 20, 240), "locked level": (50, 75, 100)
}
level = {
    1: False, 2: False, 3: False, 4: False, 5: False, 6: False, 7: False, 8: False, 9: False, 10: False
}
level_position = {
    1: (200, 800), 2: (350, 500), 3: (600, 900), 4: (800, 550), 5: (650, 350), 6: (1000, 100), 7: (1150, 350),
    8: (1400, 750), 9: (1750, 650), 10: (1600, 300), "tutorial": (875, 800)
}
tutorial_obstacles = {
    "x": 2500, "y": 400, "wide": 40, "high": 800, "color": "White", "speed": 1
}

player_y = 540
speed = 5
velocity = 0

print(pygame.font.get_fonts())
tip_font = pygame.font.Font(None, 24)
menu_font = pygame.font.Font(pygame.font.match_font("impact"), 48)
normal_font = pygame.font.Font(None, 60)
back_font = pygame.font.Font(pygame.font.match_font("bookantiqua"), 60)
boss_font = pygame.font.Font(None, 180)
title_font = pygame.font.Font(pygame.font.match_font("comicsans", True, True), 180)


# I didn't originally have this as a function, but I loved it so much it was just easier
def back_button():
    # Draws back button
    pygame.draw.rect(screen, "Red", (100, 100, 300, 100))  # Base
    pygame.draw.rect(screen, "Orange", (110, 110, 280, 80))  # Flair
    text_box("Back", "Black", back_font, 220, 115)  # Text
    pygame.draw.polygon(screen, "Black", [(200, 130), (150, 150), (200, 170)])  # Arrow


# Generates text at a location
def text_box(text, color, font, x, y):
    words = font.render(text, True, color)
    screen.blit(words, (x, y))


# Draws a button that has text in the center
def draw_button(x, y, wide, high, color, text, font, text_color):
    pygame.draw.rect(screen, color, (x, y, wide, high))
    button_text = font.render(text, True, text_color)
    text_rect = button_text.get_rect(center=(x + wide / 2, y + high / 2))
    screen.blit(button_text, text_rect)


def character_circle(resize, x, y):
    pygame.draw.circle(screen, colors["character outline"], ((125 * resize) + x, ((125 * resize) + y)),
                       115 * resize)  # Base
    pygame.draw.circle(screen, "Black", ((125 * resize) + x, (140 * resize) + y), 50 * resize)  # Mouth
    pygame.draw.circle(screen, colors["character outline"], ((125 * resize) + x, (105 * resize) + y),
                       65 * resize)  # Cover
    pygame.draw.circle(screen, "Black", ((75 * resize) + x, (100 * resize) + y), 25 * resize)  # Left eye
    pygame.draw.circle(screen, colors["character outline"], ((75 * resize) + x, (125 * resize) + y),
                       25 * resize)  # Cover
    pygame.draw.circle(screen, "Black", ((175 * resize) + x, (100 * resize) + y), 25 * resize)  # Right eye
    pygame.draw.circle(screen, colors["character outline"], ((175 * resize) + x, (125 * resize) + y),
                       25 * resize)  # Cover


def character_square(resize, x, y):
    pygame.draw.rect(screen, colors["character outline"],
                     ((0 * resize) + x, (0 * resize) + y, 220 * resize, 220 * resize))  # Base
    pygame.draw.circle(screen, "Black", ((60 * resize) + x, (70 * resize) + y), 25 * resize)  # Left eye
    pygame.draw.rect(screen, colors["character outline"],
                     ((35 * resize) + x, (45 * resize) + y, 50 * resize, 20 * resize))  # Cover
    pygame.draw.circle(screen, "Black", ((160 * resize) + x, (70 * resize) + y), 25 * resize)  # Right eye
    pygame.draw.rect(screen, colors["character outline"],
                     ((135 * resize) + x, (45 * resize) + y, 50 * resize, 20 * resize))  # Cover
    pygame.draw.rect(screen, "Black", ((50 * resize) + x, (155 * resize) + y, 120 * resize, 10 * resize))  # Mouth


def character_triangle(resize, x, y):
    pygame.draw.polygon(screen, colors["character outline"], [((0 * resize) + x, (0 * resize) + y),
                                                              ((300 * resize) + x, (0 * resize) + y),
                                                              ((150 * resize) + x, (220 * resize) + y)])  # Base
    pygame.draw.circle(screen, "Black", ((150 * resize) + x, (145 * resize) + y), 30 * resize)  # Mouth
    pygame.draw.circle(screen, colors["character outline"], ((150 * resize) + x, (160 * resize) + y),
                       30 * resize)  # Cover
    pygame.draw.polygon(screen, "Black", [((70 * resize) + x, (20 * resize) + y),
                                          ((90 * resize) + x, (80 * resize) + y),
                                          ((140 * resize) + x, (70 * resize) + y)])  # Left eye
    pygame.draw.polygon(screen, "Black", [((230 * resize) + x, (20 * resize) + y),
                                          ((210 * resize) + x, (80 * resize) + y),
                                          ((160 * resize) + x, (70 * resize) + y)])  # Right eye


def character_star(resize, x, y):
    point_1 = ((125 * resize) + x, (0 * resize) + y)
    point_2 = ((250 * resize) + x, (90 * resize) + y)
    point_3 = ((200 * resize) + x, (220 * resize) + y)
    point_4 = ((50 * resize) + x, (220 * resize) + y)
    point_5 = ((0 * resize) + x, (90 * resize) + y)
    pygame.draw.polygon(screen, colors["character outline"], [point_1, ((160 * resize) + x, (90 * resize) + y),
                                                              point_2, ((180 * resize) + x, (145 * resize) + y),
                                                              point_3, ((125 * resize) + x, (175 * resize) + y),
                                                              point_4, ((70 * resize) + x, (145 * resize) + y),
                                                              point_5, ((90 * resize) + x, (90 * resize) + y)])
    pygame.draw.circle(screen, "Black", ((125 * resize) + x, (155 * resize) + y), 18 * resize)  # Mouth
    pygame.draw.circle(screen, "Black", ((100 * resize) + x, (110 * resize) + y), 15 * resize)  # Left eye
    pygame.draw.circle(screen, "Black", ((150 * resize) + x, (110 * resize) + y), 15 * resize)  # Right eye


def obstacle(x, y, wide, high, color):
    pygame.draw.rect(screen, color, (x, y, wide, high))


# GAME STARTS HERE
state = "menu"
character = ""
beat = 0

while True:
    for event in pygame.event.get():
        if state == "menu":

            # Draws menu display
            screen.fill("Black")
            # To do list
            text_box("To do list", "White", normal_font, 100, 750)
            text_box("Add FLAIR to boring menu screen", "White", tip_font, 100, 825)
            text_box("Possible animation", "White", tip_font, 100, 850)
            text_box("Individual character levels", "White", tip_font, 100, 875)
            text_box("Figure out how to save levels", "White", tip_font, 100, 900)
            text_box("Add custom music and sound effects", "White", tip_font, 100, 925)
            text_box("FINISH THE LEVELS", "White", tip_font, 100, 950)
            # Quit button
            draw_button(740, 690, 440, 100, "White", "Quit", menu_font, "Black")
            # Start button
            draw_button(740, 540, 440, 100, "White", "Start", menu_font, "Black")
            # Title
            draw_button(300, 100, 1320, 350, "Black", "F O R W A R D", title_font, "darkcyan")

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 740 <= event.pos[0] <= 1180 and 690 <= event.pos[1] <= 790:
                    # clicked the quit button
                    pygame.quit()
                    sys.exit()
                elif 740 <= event.pos[0] <= 1180 and 540 <= event.pos[1] <= 640:
                    # clicked the start button
                    state = "characters 1"

        elif state == "characters 1":

            # Draw the character selection screen display
            screen.fill("Black")
            # Draws character circle
            pygame.draw.rect(screen, colors["character"], (550, 190, 400, 700))
            pygame.draw.rect(screen, "Red", (600, 720, 300, 100))
            draw_button(610, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")
            character_circle(1, 625, 320)
            # Draws character square
            pygame.draw.rect(screen, colors["character"], (1000, 190, 400, 700))
            pygame.draw.rect(screen, "Red", (1050, 720, 300, 100))
            draw_button(1060, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")
            character_square(1, 1090, 345)
            # Draws arrow for more characters
            pygame.draw.polygon(screen, colors["character"], [(1550, 450), (1700, 550), (1550, 650)])
            back_button()

            # Hover over choose command
            if 600 <= pygame.mouse.get_pos()[0] <= 900 and 720 <= pygame.mouse.get_pos()[1] <= 820:
                pygame.draw.rect(screen, "White", (600, 720, 300, 100))
                draw_button(610, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")
            elif 1050 <= pygame.mouse.get_pos()[0] <= 1350 and 720 <= pygame.mouse.get_pos()[1] <= 820:
                pygame.draw.rect(screen, "White", (1050, 720, 300, 100))
                draw_button(1060, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")

            # Mouse clicks
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "menu"
                elif 1550 <= event.pos[0] <= 1700 and 450 <= event.pos[1] <= 650:
                    # Clicked in the general area of the more characters button
                    state = "characters 2"
                elif 600 <= event.pos[0] <= 900 and 720 <= event.pos[1] <= 820:
                    state = "levels"
                    character = "circle"
                elif 1050 <= event.pos[0] <= 1350 and 720 <= event.pos[1] <= 820:
                    state = "levels"
                    character = "square"
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 5
                    or event.type == pygame.KEYDOWN and event.key == pygame.K_d):
                state = "characters 2"

        elif state == "characters 2":

            # Draw the display
            screen.fill("Black")
            # Draws character triangle
            pygame.draw.rect(screen, colors["character"], (550, 190, 400, 700))
            character_triangle(1, 600, 345)
            pygame.draw.rect(screen, "Red", (600, 720, 300, 100))
            draw_button(610, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")
            # Draws character star
            pygame.draw.rect(screen, colors["character"], (1000, 190, 400, 700))
            character_star(1, 1075, 345)
            pygame.draw.rect(screen, "Red", (1050, 720, 300, 100))
            draw_button(1060, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")
            # Draws arrow for more characters
            # pygame.draw.polygon(screen, colors["character"], [(1550, 450), (1700, 550), (1550, 650)])  # Right
            pygame.draw.polygon(screen, colors["character"], [(400, 450), (250, 550), (400, 650)])  # Left
            back_button()

            # Hover over choose command
            if 600 <= pygame.mouse.get_pos()[0] <= 900 and 720 <= pygame.mouse.get_pos()[1] <= 820:
                pygame.draw.rect(screen, "White", (600, 720, 300, 100))
                draw_button(610, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")
            elif 1050 <= pygame.mouse.get_pos()[0] <= 1350 and 720 <= pygame.mouse.get_pos()[1] <= 820:
                pygame.draw.rect(screen, "White", (1050, 720, 300, 100))
                draw_button(1060, 730, 280, 80, "Black", "CHOOSE", menu_font, "White")

            # Mouse click
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "menu"
                elif 250 <= event.pos[0] <= 400 and 450 <= event.pos[1] <= 650:
                    # Clicked in the general area of the more characters button
                    state = "characters 1"
                elif 600 <= event.pos[0] <= 900 and 720 <= event.pos[1] <= 820:
                    character = "triangle"
                    state = "levels"
                elif 1050 <= event.pos[0] <= 1350 and 720 <= event.pos[1] <= 820:
                    character = "star"
                    state = "levels"
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 4
                    or event.type == pygame.KEYDOWN and event.key == pygame.K_a):
                state = "characters 1"

        elif state == "levels":

            # Shows the level map
            screen.fill("Grey")
            player_y = 540
            # Draws the correct color coded level layout depending on completion status
            counter = 1
            for i in level:
                if level[counter]:
                    pygame.draw.circle(screen, colors["complete level"], level_position[counter], 50)
                    text_box(str(counter), "White", normal_font,
                             level_position[counter][0] - 10, level_position[counter][1] - 15)
                    counter += 1
                elif counter == 1 or level[counter - 1]:
                    pygame.draw.circle(screen, colors["doable level"], level_position[counter], 50)
                    text_box(str(counter), "White", normal_font,
                             level_position[counter][0] - 10, level_position[counter][1] - 15)
                    counter += 1
                else:
                    pygame.draw.circle(screen, colors["locked level"], level_position[counter], 50)
                    text_box(str(counter), "White", normal_font,
                             level_position[counter][0] - 10, level_position[counter][1] - 15)
                    counter += 1
            pygame.draw.circle(screen, "Black", level_position[10], 125)
            if level[9]:
                pygame.draw.circle(screen, colors["doable level"], level_position[10], 125)
            if level[10]:
                pygame.draw.circle(screen, colors["complete level"], level_position[10], 125)
            text_box("10", "Red", boss_font, 1535, 245)
            draw_button(level_position["tutorial"][0], level_position["tutorial"][1], 350, 150, "Black", "TUTORIAL",
                        normal_font, "Pink")

            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "characters 1"
                elif (level_position["tutorial"][0] <= event.pos[0] <= level_position["tutorial"][0] + 350 and
                      level_position["tutorial"][1] <= event.pos[1] <= level_position["tutorial"][1] + 150):
                    state = "tutorial level"
                elif (level_position[1][0] - 50 <= event.pos[0] <= level_position[1][0] + 50 and
                      level_position[1][1] - 50 <= event.pos[1] <= level_position[1][1] + 50):
                    state = "level 1"
                if level[1]:
                    if (level_position[2][0] - 50 <= event.pos[0] <= level_position[2][0] + 50 and
                            level_position[2][1] - 50 <= event.pos[1] <= level_position[2][1] + 50):
                        state = "level 2"
                if level[2]:
                    if (level_position[3][0] - 50 <= event.pos[0] <= level_position[3][0] + 50 and
                            level_position[3][1] - 50 <= event.pos[1] <= level_position[3][1] + 50):
                        state = "level 3"
                if level[3]:
                    if (level_position[4][0] - 50 <= event.pos[0] <= level_position[4][0] + 50 and
                            level_position[4][1] - 50 <= event.pos[1] <= level_position[4][1] + 50):
                        state = "level 4"
                if level[4]:
                    if (level_position[5][0] - 50 <= event.pos[0] <= level_position[5][0] + 50 and
                            level_position[5][1] - 50 <= event.pos[1] <= level_position[5][1] + 50):
                        state = "level 5"
                if level[5]:
                    if (level_position[6][0] - 50 <= event.pos[0] <= level_position[6][0] + 50 and
                            level_position[6][1] - 50 <= event.pos[1] <= level_position[6][1] + 50):
                        state = "level 6"
                if level[6]:
                    if (level_position[7][0] - 50 <= event.pos[0] <= level_position[7][0] + 50 and
                            level_position[7][1] - 50 <= event.pos[1] <= level_position[7][1] + 50):
                        state = "level 7"
                if level[7]:
                    if (level_position[8][0] - 50 <= event.pos[0] <= level_position[8][0] + 50 and
                            level_position[8][1] - 50 <= event.pos[1] <= level_position[8][1] + 50):
                        state = "level 8"
                if level[8]:
                    if (level_position[9][0] - 50 <= event.pos[0] <= level_position[9][0] + 50 and
                            level_position[9][1] - 50 <= event.pos[1] <= level_position[9][1] + 50):
                        state = "level 9"
                if level[9]:
                    if (level_position[10][0] - 125 <= event.pos[0] <= level_position[10][0] + 125 and
                            level_position[10][1] - 125 <= event.pos[1] <= level_position[10][1] + 125):
                        state = "level 10"

        elif state == "tutorial level":

            # Draw the initial display
            screen.fill("skyblue")

            if character == "circle":
                keys = pygame.key.get_pressed()
                if keys[pygame.K_w] and player_y > 0:
                    velocity = -speed
                    player_y += velocity
                elif keys[pygame.K_s] and player_y < 970:
                    velocity = speed
                    player_y += velocity
                else:
                    velocity = 0
                character_circle(.5, 300, player_y)
            if character == "square":
                keys = pygame.key.get_pressed()
                if keys[pygame.K_w] and player_y > 0:
                    velocity = -speed
                    player_y += velocity
                elif keys[pygame.K_s] and player_y < 970:
                    velocity = speed
                    player_y += velocity
                else:
                    velocity = 0
                character_square(.5, 300, player_y)
            if character == "triangle":
                keys = pygame.key.get_pressed()
                if keys[pygame.K_w] and player_y > 0:
                    velocity = -speed
                    player_y += velocity
                elif keys[pygame.K_s] and player_y < 970:
                    velocity = speed
                    player_y += velocity
                else:
                    velocity = 0
                character_triangle(.5, 300, player_y)
            if character == "star":
                keys = pygame.key.get_pressed()
                if keys[pygame.K_w] and player_y > 0:
                    velocity = -speed
                    player_y += velocity
                elif keys[pygame.K_s] and player_y < 970:
                    velocity = speed
                    player_y += velocity
                else:
                    velocity = 0
                character_star(.5, 300, player_y)
            pygame.draw.rect(screen, "White", (0, 0, 10000, 80))
            pygame.draw.rect(screen, "White", (0, 1000, 10000, 80))
            for obstacles in tutorial_obstacles:
                tutorial_obstacles["x"] -= tutorial_obstacles["speed"]
                obstacle(tutorial_obstacles["x"], tutorial_obstacles["y"], tutorial_obstacles["wide"],
                         tutorial_obstacles["high"], tutorial_obstacles["color"])

        elif state == "level 1":

            # Draw the initial display
            screen.fill("lightblue")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")

            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[1] = True
        elif state == "level 2":

            # Draw the initial display
            screen.fill("darkcyan")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[2] = True
        elif state == "level 3":

            # Draw the initial display
            screen.fill("violet")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[3] = True
        elif state == "level 4":

            # Draw the initial display
            screen.fill("forestgreen")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[4] = True
        elif state == "level 5":

            # Draw the initial display
            screen.fill("darkgreen")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[5] = True
        elif state == "level 6":

            # Draw the initial display
            screen.fill("aqua")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[6] = True
        elif state == "level 7":

            # Draw the initial display
            screen.fill("darkblue")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[7] = True
        elif state == "level 8":

            # Draw the initial display
            screen.fill("dimgrey")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[8] = True
        elif state == "level 9":

            # Draw the initial display
            screen.fill("black")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[9] = True
        elif state == "level 10":

            # Draw the initial display
            screen.fill("darkred")
            draw_button(500, 500, 500, 500, "White", "COMPLETE LEVEL", menu_font, "Green")
            back_button()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if 100 <= event.pos[0] <= 400 and 100 <= event.pos[1] <= 200:
                    # Clicked the back button
                    state = "levels"
                elif 500 <= event.pos[0] <= 1000 and 500 <= event.pos[1] <= 1000:
                    # Clicked the win button
                    level[10] = True

        # Pygame systems
        pygame.display.flip()
        pygame.time.Clock().tick(60)
